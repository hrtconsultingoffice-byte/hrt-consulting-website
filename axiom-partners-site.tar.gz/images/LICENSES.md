# 写真の出典と利用条件

| ファイル | 写真・作者 | ライセンス | 表示時の調整 |
| --- | --- | --- | --- |
| marunouchi.jpg | [Marunouchi Central Plaza with blue sky…](https://commons.wikimedia.org/wiki/File:Marunouchi_Central_Plaza_with_blue_sky,_Tokyo_station_and_Shin-Marunouchi_Building,_panoramic_view_from_JP_Tower,_Tokyo,_Japan.jpg) / Basile Morin | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) | 配布元の縮小版を取得。CSSで表示範囲と彩度を調整し、グラデーションを重ねています。画像の改変版を配布する場合は同ライセンスの条件に従ってください。 |
| meeting.jpg | [Minimalist meeting room](https://commons.wikimedia.org/wiki/File:Minimalist_meeting_room_(Unsplash).jpg) / Breather | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) | 配布元の縮小版を取得。CSSで表示範囲と彩度を調整しています。 |

写真は建築や会議空間のイメージです。AXIOM PARTNERSの所在地や設備を示すものではありません。
写真を差し替える際は lib/site.ts のパスと代替テキスト、app/layout.tsx のOGP画像、フッターのクレジットも更新してください。
